package java8lambdasstream;

import java.awt.List;

class TempStudent {
    public String name;
    public int age;
    public Address address;
    public List mobileNumbers;
 
    public TempStudent(String name, int age, Address address, List mobileNumbers) {
        this.name = name;
        this.age = age;
        this.address = address;
        this.mobileNumbers = mobileNumbers;
    }
}